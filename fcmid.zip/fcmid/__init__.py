# flake8: noqa
"""fuzzy-c-medians - A simple implementation of Fuzzy C-medians algorithm."""
from .main import FCMid

__version__ = "1.6.4"
